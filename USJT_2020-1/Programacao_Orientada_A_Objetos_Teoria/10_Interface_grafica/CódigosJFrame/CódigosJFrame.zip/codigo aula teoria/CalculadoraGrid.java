public class CalculadoraGrid{

   public static void main(String[] args){
      //instancia o JFrame
      TelaCalculadoraGrid tela = new TelaCalculadoraGrid();      
   }
} 