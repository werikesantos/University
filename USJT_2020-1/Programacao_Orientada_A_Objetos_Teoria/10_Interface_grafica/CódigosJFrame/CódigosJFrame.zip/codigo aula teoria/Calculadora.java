public class Calculadora{

   public static void main(String[] args){
      //instancia o JFrame
      TelaCalculadora tela = new TelaCalculadora();      
   }
} 