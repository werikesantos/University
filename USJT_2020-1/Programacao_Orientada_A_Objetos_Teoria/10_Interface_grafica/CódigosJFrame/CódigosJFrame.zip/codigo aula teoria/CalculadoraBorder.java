public class CalculadoraBorder{

   public static void main(String[] args){
      //instancia o JFrame
      TelaCalculadoraBorder tela = new TelaCalculadoraBorder();      
   }
} 