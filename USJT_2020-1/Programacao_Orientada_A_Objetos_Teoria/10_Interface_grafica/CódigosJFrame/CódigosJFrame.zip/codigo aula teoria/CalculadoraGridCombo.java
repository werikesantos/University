public class CalculadoraGridCombo{

   public static void main(String[] args){
      //instancia o JFrame
      TelaCalculadoraCombo tela = new TelaCalculadoraCombo();      
   }
} 