public class TesteTelaMix{

   public static void main(String[] args){
      new TelaMix();
   }
}