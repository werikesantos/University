public class TesteTelaBorder{

   public static void main(String[] args){
      new TelaBorder();
   }
}