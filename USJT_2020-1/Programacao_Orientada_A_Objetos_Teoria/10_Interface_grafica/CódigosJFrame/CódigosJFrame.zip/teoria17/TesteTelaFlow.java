public class TesteTelaFlow{

   public static void main(String[] args){
      new TelaFlow();
   }
}