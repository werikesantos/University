public class TesteTelaGrid{

   public static void main(String[] args){
      new TelaGrid();
   }
}