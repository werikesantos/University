import javax.swing.JOptionPane;
public class Teste{
   public static void main(String[] args)
   {
       new Tela();       
   }
}

